#!/bin/sh

#  Invinet XML Tools  
#  Created by:  Oriol Baus� (2010) Invinet Sistemes
#  Copyright (C) - Invinet Sistemes 2003 - http://www.invinet.org


# create schematron from odds
../../utilities/e2sch.rb businessrules/biicore-T01-BusinessRules-v01.ods schematron BIICORE
../../utilities/e2sch.rb businessrules/biicore-T10-BusinessRules-v01.ods schematron BIICORE
../../utilities/e2sch.rb businessrules/biicore-T14-BusinessRules-v01.ods schematron BIICORE
../../utilities/e2sch.rb businessrules/biicore-T15-BusinessRules-v01.ods schematron BIICORE

# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIICORE-UBL-T01
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIICORE-UBL-T10
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIICORE-UBL-T14
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIICORE-UBL-T15

# correct bug in resulting xslts: <axsl:param name=" ... " tunnel="no"/>
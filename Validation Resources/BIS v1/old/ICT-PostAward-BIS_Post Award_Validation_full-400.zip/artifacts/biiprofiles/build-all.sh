#!/bin/sh

#  Invinet XML Tools  
#  Created by:  Oriol Baus� (2010) Invinet Sistemes
#  Copyright (C) - Invinet Sistemes 2003 - http://www.invinet.org

# create schematron from ods
../../utilities/e2sch.rb businessrules/biiprofiles-T10-BusinessRules-v01.ods schematron BIIPROFILES
../../utilities/e2sch.rb businessrules/biiprofiles-T14-BusinessRules-v01.ods schematron BIIPROFILES
../../utilities/e2sch.rb businessrules/biiprofiles-T15-BusinessRules-v01.ods schematron BIIPROFILES

# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIIPROFILES-UBL-T10
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIIPROFILES-UBL-T14
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIIPROFILES-UBL-T15

# correct bug in resulting xslts: <axsl:param name=" ... " tunnel="no"/>

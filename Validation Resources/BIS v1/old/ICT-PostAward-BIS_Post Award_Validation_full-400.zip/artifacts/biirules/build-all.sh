#!/bin/sh

#  Invinet XML Tools  
#  Created by:  Oriol Baus� (2010) Invinet Sistemes
#  Copyright (C) - Invinet Sistemes 2003 - http://www.invinet.org

# generate genericodes and cva for every Transaction in BIIRULES
../../utilities/e2gc-cva.rb businessrules/biirules-CodeLists-v01.ods BIIRULES gc cva

echo "Create schematron for codelists in T10"
../../utilities/create_code_rules.sh ../../utilities BIIRULESCodesT10


echo "Create schematron from ods adding codelist T10 rules"
../../utilities/e2sch.rb businessrules/biirules-T10-BusinessRules-v02.ods schematron BIIRULES BIIRULESCodesT10.sch

echo "Assemblying to xslt validation sheet"
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIIRULES-UBL-T10

echo "======================================"
echo "Create schematron for codelists in T15"
../../utilities/create_code_rules.sh ../../utilities BIIRULESCodesT15


echo "Create schematron from ods  adding codelist T15 rules"
../../utilities/e2sch.rb businessrules/biirules-T15-BusinessRules-v01.ods schematron BIIRULES BIIRULESCodesT15.sch

echo "Assemblying to xslt validation sheet"
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIIRULES-UBL-T15

echo "======================================"
echo "Create schematron for codelists in T14"
../../utilities/create_code_rules.sh ../../utilities BIIRULESCodesT14


echo "Create schematron from ods  adding codelist T14 rules"
../../utilities/e2sch.rb businessrules/biirules-T14-BusinessRules-v01.ods schematron BIIRULES BIIRULESCodesT14.sch

echo "Assemblying to xslt validation sheet"
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIIRULES-UBL-T14

echo "======================================"
echo "Create schematron for codelists in T01"
../../utilities/create_code_rules.sh ../../utilities BIIRULESCodesT01


echo "Create schematron from ods  adding codelist T01 rules"
../../utilities/e2sch.rb businessrules/biirules-T01-BusinessRules-v02.ods schematron BIIRULES BIIRULESCodesT01.sch

echo "Assemblying to xslt validation sheet"
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIIRULES-UBL-T01

echo "======================================"
echo "Create schematron from ods  adding codelist T02 rules"
../../utilities/e2sch.rb businessrules/biirules-T02-BusinessRules-v01.ods schematron BIIRULES 

echo "Assemblying to xslt validation sheet"
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIIRULES-UBL-T02

echo "======================================"
echo "Create schematron from ods  adding codelist T03 rules"
../../utilities/e2sch.rb businessrules/biirules-T03-BusinessRules-v01.ods schematron BIIRULES 

echo "Assemblying to xslt validation sheet"
../../utilities/create_xslt_from_sch.sh ../../utilities/ BIIRULES-UBL-T03

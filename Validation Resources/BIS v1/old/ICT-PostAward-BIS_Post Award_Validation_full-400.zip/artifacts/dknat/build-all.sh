#!/bin/sh

#  Invinet XML Tools  
#  Created by:  Oriol Baus� (2010) Invinet Sistemes
#  Copyright (C) - Invinet Sistemes 2003 - http://www.invinet.org

# generate genericodes and cva
#../../utilities/e2gc-cva.rb businessrules/atnat0001-001-CodeLists.ods atnat0001 gc cva

# create schematron for codelists
#../../utilities/create_code_rules.sh ../../utilities atnat0001CodesBiiCoreTrdm010

# create schematron from odds
../../utilities/e2sch.rb businessrules/dknat-T10-BusinessRules-v01.ods schematron DKNAT
# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ DKNAT-UBL-T10

# correct bug in resulting xslts: <axsl:param name=" ... " tunnel="no"/>

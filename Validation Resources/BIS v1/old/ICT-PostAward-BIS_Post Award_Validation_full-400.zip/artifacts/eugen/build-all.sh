#!/bin/sh

#  Invinet XML Tools  
#  Created by:  Oriol Baus� (2010) Invinet Sistemes
#  Copyright (C) - Invinet Sistemes 2003 - http://www.invinet.org

# generate genericodes and cva
../../utilities/e2gc-cva.rb businessrules/eugen-CodeLists-v01.ods EUGEN gc cva

# create schematron for codelists for T10
../../utilities/create_code_rules.sh ../../utilities EUGENCodesT10

# create schematron from odds
../../utilities/e2sch.rb businessrules/eugen-T10-BusinessRules-v01.ods schematron EUGEN EUGENCodesT10.sch

# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ EUGEN-UBL-T10

# create schematron for codelists for T14
../../utilities/create_code_rules.sh ../../utilities EUGENCodesT14

# create schematron from odds
../../utilities/e2sch.rb businessrules/eugen-T14-BusinessRules-v01.ods schematron EUGEN EUGENCodesT14.sch

# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ EUGEN-UBL-T14

# create schematron for codelists for T15
../../utilities/create_code_rules.sh ../../utilities EUGENCodesT15

# create schematron from odds
../../utilities/e2sch.rb businessrules/eugen-T15-BusinessRules-v01.ods schematron EUGEN EUGENCodesT15.sch

# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ EUGEN-UBL-T15


# create schematron from odds
../../utilities/e2sch.rb businessrules/eugen-T01-BusinessRules-v02.ods schematron EUGEN

# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ EUGEN-UBL-T01

# create schematron from odds
../../utilities/e2sch.rb businessrules/eugen-T19-BusinessRules-v01.ods schematron EUGEN

# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ EUGEN-UBL-T19

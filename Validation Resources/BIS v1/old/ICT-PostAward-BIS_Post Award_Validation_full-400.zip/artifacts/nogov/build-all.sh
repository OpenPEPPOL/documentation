#!/bin/sh

#  Invinet XML Tools  
#  Created by:  Oriol Baus� (2010) Invinet Sistemes
#  Copyright (C) - Invinet Sistemes 2003 - http://www.invinet.org

# create schematron from odds
../../utilities/e2sch.rb businessrules/nogov-T10-BusinessRules-v01.ods schematron NOGOV 
../../utilities/e2sch.rb businessrules/nogov-T14-BusinessRules-v01.ods schematron NOGOV 
../../utilities/e2sch.rb businessrules/nogov-T15-BusinessRules-v01.ods schematron NOGOV 

# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ NOGOV-UBL-T10
../../utilities/create_xslt_from_sch.sh ../../utilities/ NOGOV-UBL-T14
../../utilities/create_xslt_from_sch.sh ../../utilities/ NOGOV-UBL-T15


# correct bug in resulting xslts: <axsl:param name=" ... " tunnel="no"/>
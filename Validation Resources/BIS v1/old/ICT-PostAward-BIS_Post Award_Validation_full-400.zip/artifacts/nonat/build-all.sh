#!/bin/sh

#  Invinet XML Tools  
#  Created by:  Oriol Baus� (2010) Invinet Sistemes
#  Copyright (C) - Invinet Sistemes 2003 - http://www.invinet.org

# generate genericodes and cva
#../../utilities/e2gc-cva.rb businessrules/nonat0001-001-CodeLists.ods nonat0001 gc cva

# create schematron for codelists
#../../utilities/create_code_rules.sh ../../utilities nonat0001CodesBiiCoreTrdm010

# create schematron from odds
../../utilities/e2sch.rb businessrules/nonat-T10-BusinessRules-v01.ods schematron NONAT 
../../utilities/e2sch.rb businessrules/nonat-T14-BusinessRules-v01.ods schematron NONAT 
../../utilities/e2sch.rb businessrules/nonat-T15-BusinessRules-v01.ods schematron NONAT 

# assembly to xslt
../../utilities/create_xslt_from_sch.sh ../../utilities/ NONAT-UBL-T10
../../utilities/create_xslt_from_sch.sh ../../utilities/ NONAT-UBL-T14
../../utilities/create_xslt_from_sch.sh ../../utilities/ NONAT-UBL-T15


# correct bug in resulting xslts: <axsl:param name=" ... " tunnel="no"/>
#!/bin/sh

#  Invinet XML Tools  
#  Purpose: Shell script to create code list validation fragments in Schematron format
#           based on a set of genericode files and a context value association
#
#			It validates the cva file and uses Crane artifacts to create the 
#			Schematron fragment
#
#  Input: Genericode and CVAfiles 
#  Output: Schematron fragment to be included in a validation package
#
#  Usage: create_code_rules.sh <utilities folder> <cva_file_without_extension>
# 
#  Created by:  Oriol Bausà (2010) Invinet Sistemes
#  Copyright (C) - Invinet Sistemes 2003 - http://www.invinet.org
#

echo Validating partner-agreed constraints...
echo   w3cschema ContextValueAssociation.xsd $1.cva
$1/w3cschema.sh $1/ContextValueAssociation.xsd cva/$2.cva 2>&1 >output.txt

echo
echo Preparing code list rules...
echo
echo Translating partner-agreed constraints into Schematron rules...
echo  $1/xslt cva/$2.cva $1/Crane-NM-genericode2Schematron.xsl schematron/codelist/$2.sch
$1/xslt.sh cva/$2.cva $1/Crane-NM-genericode2Schematron.xsl schematron/codelist/$2.sch >output.txt

echo
echo Done.

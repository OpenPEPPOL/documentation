#!/bin/sh

#  Invinet XML Tools  
#  Purpose: Shell script to create a business rule validation engine in XSLT format
#           based on a set of schematron business rule and codelist fragments
#
#
#  Input: Schemtron structure
#  Output: XSLT file
#
#  Usage: create_xslt_from_sch.sh <utilities folder> <schematron_main_file_without_extension>
# 
#  Created by:  Oriol Bausà (2010) Invinet Sistemes
#  Copyright (C) - Invinet Sistemes 2003 - http://www.invinet.org

# include all the imports
$1/xslt.sh schematron/$2.sch $1/iso_dsdl_include.xsl schematron/temp/$2_abstract.sch >output.txt

# expand abstracts
$1/xslt.sh schematron/temp/$2_abstract.sch $1/iso_abstract_expand.xsl schematron/temp/$2_assy.sch >output.txt

# assembly into xslt
$1/xslt.sh schematron/temp/$2_assy.sch $1/iso_svrl.xsl validation-xslt/$2.xsl >output.txt

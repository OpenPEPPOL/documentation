#!/bin/sh

# include all the imports
./xslt.sh ../cenbii-schematron/BII04BiiCoreTrdm010ubl.sch ./iso_dsdl_include.xsl ../cenbii-schematron/temp/BII04BiiCoreTrdm010ubl_abstract.sch >output.txt
./xslt.sh ../cenbii-schematron/BII23BiiCoreTrdm010ubl.sch ./iso_dsdl_include.xsl ../cenbii-schematron/temp/BII23BiiCoreTrdm010ubl_abstract.sch >output.txt
./xslt.sh ../cenbii-schematron/BII05BiiCoreTrdm010ubl.sch ./iso_dsdl_include.xsl ../cenbii-schematron/temp/BII05BiiCoreTrdm010ubl_abstract.sch >output.txt
./xslt.sh ../cenbii-schematron/BII06BiiCoreTrdm010ubl.sch ./iso_dsdl_include.xsl ../cenbii-schematron/temp/BII06BiiCoreTrdm010ubl_abstract.sch >output.txt
./xslt.sh ../cenbii-schematron/BII07BiiCoreTrdm010ubl.sch ./iso_dsdl_include.xsl ../cenbii-schematron/temp/BII07BiiCoreTrdm010ubl_abstract.sch >output.txt
./xslt.sh ../cenbii-schematron/BII08BiiCoreTrdm010ubl.sch ./iso_dsdl_include.xsl ../cenbii-schematron/temp/BII08BiiCoreTrdm010ubl_abstract.sch >output.txt
./xslt.sh ../cenbii-schematron/BII13BiiCoreTrdm010ubl.sch ./iso_dsdl_include.xsl ../cenbii-schematron/temp/BII13BiiCoreTrdm010ubl_abstract.sch >output.txt
./xslt.sh ../cenbii-schematron/BII19BiiCoreTrdm010ubl.sch ./iso_dsdl_include.xsl ../cenbii-schematron/temp/BII19BiiCoreTrdm010ubl_abstract.sch >output.txt

# expand abstracts
./xslt.sh ../cenbii-schematron/temp/BII04BiiCoreTrdm010ubl_abstract.sch ./iso_abstract_expand.xsl ../cenbii-schematron/temp/BII04BiiCoreTrdm010ubl_assy.sch >output.txt
./xslt.sh ../cenbii-schematron/temp/BII23BiiCoreTrdm010ubl_abstract.sch ./iso_abstract_expand.xsl ../cenbii-schematron/temp/BII23BiiCoreTrdm010ubl_assy.sch >output.txt
./xslt.sh ../cenbii-schematron/temp/BII05BiiCoreTrdm010ubl_abstract.sch ./iso_abstract_expand.xsl ../cenbii-schematron/temp/BII05BiiCoreTrdm010ubl_assy.sch >output.txt
./xslt.sh ../cenbii-schematron/temp/BII06BiiCoreTrdm010ubl_abstract.sch ./iso_abstract_expand.xsl ../cenbii-schematron/temp/BII06BiiCoreTrdm010ubl_assy.sch >output.txt
./xslt.sh ../cenbii-schematron/temp/BII07BiiCoreTrdm010ubl_abstract.sch ./iso_abstract_expand.xsl ../cenbii-schematron/temp/BII07BiiCoreTrdm010ubl_assy.sch >output.txt
./xslt.sh ../cenbii-schematron/temp/BII08BiiCoreTrdm010ubl_abstract.sch ./iso_abstract_expand.xsl ../cenbii-schematron/temp/BII08BiiCoreTrdm010ubl_assy.sch >output.txt
./xslt.sh ../cenbii-schematron/temp/BII13BiiCoreTrdm010ubl_abstract.sch ./iso_abstract_expand.xsl ../cenbii-schematron/temp/BII13BiiCoreTrdm010ubl_assy.sch >output.txt
./xslt.sh ../cenbii-schematron/temp/BII19BiiCoreTrdm010ubl_abstract.sch ./iso_abstract_expand.xsl ../cenbii-schematron/temp/BII19BiiCoreTrdm010ubl_assy.sch >output.txt

# assembly into xslt
./xslt.sh ../cenbii-schematron/temp/BII04BiiCoreTrdm010ubl_assy.sch ./iso_svrl.xsl ../validation-xslt/BII04BiiCoreTrdm010ubl.xsl >output.txt
./xslt.sh ../cenbii-schematron/temp/BII23BiiCoreTrdm010ubl_assy.sch ./iso_svrl.xsl ../validation-xslt/BII23BiiCoreTrdm010ubl.xsl >output.txt
./xslt.sh ../cenbii-schematron/temp/BII05BiiCoreTrdm010ubl_assy.sch ./iso_svrl.xsl ../validation-xslt/BII05BiiCoreTrdm010ubl.xsl >output.txt
./xslt.sh ../cenbii-schematron/temp/BII06BiiCoreTrdm010ubl_assy.sch ./iso_svrl.xsl ../validation-xslt/BII06BiiCoreTrdm010ubl.xsl >output.txt
./xslt.sh ../cenbii-schematron/temp/BII07BiiCoreTrdm010ubl_assy.sch ./iso_svrl.xsl ../validation-xslt/BII07BiiCoreTrdm010ubl.xsl >output.txt
./xslt.sh ../cenbii-schematron/temp/BII08BiiCoreTrdm010ubl_assy.sch ./iso_svrl.xsl ../validation-xslt/BII08BiiCoreTrdm010ubl.xsl >output.txt
./xslt.sh ../cenbii-schematron/temp/BII13BiiCoreTrdm010ubl_assy.sch ./iso_svrl.xsl ../validation-xslt/BII13BiiCoreTrdm010ubl.xsl >output.txt
./xslt.sh ../cenbii-schematron/temp/BII19BiiCoreTrdm010ubl_assy.sch ./iso_svrl.xsl ../validation-xslt/BII19BiiCoreTrdm010ubl.xsl >output.txt


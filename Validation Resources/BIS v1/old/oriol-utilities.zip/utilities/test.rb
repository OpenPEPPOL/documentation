#!/usr/bin/ruby

# Invinet XML Tools  
# Purpose: Ruby tool to test Schematron  rules and syntax binding
# 
#
# Usage: ./test.rb
#
# Output: Creates a Test-result.html
#
# Author: Oriol Bausà (2010) Invinet Sistemes
# INSTALL
#
# Requisites:
#
#   sudo gem install firewatir watir roo rubyzip nokogiri spreadsheet google_spreadsheet google-spreadsheet-ruby
#
# RUN 
#
# Mac: open firefox with 
#
#     open -a /Applications/Firefox.app --args -jssh

require 'rubygems'
require 'roo'
require 'watir'
require 'fileutils'

include FileUtils



puts "Testing CEN BII artefacts"

def main

Watir::Browser.default = 'firefox'
b = Watir::Browser.new

chdir "../test"
oo = Openoffice.new("Peppol WP5 Test Case List 04.ods")
oo.default_sheet = oo.sheets[1]


file = File.new("Test-result.html","w")



# array with ruleset identifiers in the web tool drop down box
rulesets = oo.row(2)

		
b.goto "http://www.invinet.org/recursos/conformance/invoice-validation.html"




3.upto(oo.last_row) do |testcase|
	testfile = oo.cell(testcase,'A')
	
	errors = oo.row(testcase)
	tf = TestCase.new(testfile, rulesets, b, errors, file)
	tf.load
end



end

class TestCase
	attr_accessor :id, :instance, :rulesets, :browser, :errors, :file
	
	def initialize(instance, rulesets, browser, errors, file)
		@instance = instance
		@rulesets = rulesets
		@browser = browser
		@errors = errors
		@file = file
	end

	def load
		
		file.puts "<h1>Opening test instance : " + instance + "<h1>"
		
        field = browser.text_field(:id=> "xmlTextSource")

        # the gsub assures it is not a cr+lf dos file
        field.value = File.read(instance).gsub(/\r\n?/, "\n")

		
		1.upto(rulesets.length) do |ruleset|

			if errors[ruleset] != nil then
				browser.select_list(:id => "xsltSelect").clear
				file.puts "<h2> Testing ruleset : " + rulesets[ruleset] + "</h2>"
				tst = RuleSetTest.new(rulesets[ruleset], browser, errors[ruleset], file)
				tst.test
			end
		end
	end
end

class RuleSetTest
	attr_accessor :id, :ruleset, :browser, :errors, :file

	def initialize(ruleset, browser, errors, file)
		@ruleset = ruleset
		@browser = browser
		@errors = errors
		@file = file
	end
	
	def test
		browser.select_list(:id => "xsltSelect").select "#{ruleset}"

		browser.button(:id, "readFileButton").click


		file.puts "<h2>Validation output</h2>"

		browser.div(:id,"transformResult").ps.each do |t|
			
			file.puts t.text+"<br/>"
			
		end

		file.puts "<h2>Result</h2>"

		if (errors == "No")
			file.puts "<h3>No errors expected</h3>"
			if browser.contains_text("ERROR") then file.puts "<font color='red'>Test failed! Errors found!</font><br/>" 
			else file.puts "<font color='green'>Test passed. No errors</font><br/>" end
			if browser.contains_text("Warning") then file.puts "<font color='red'>Test failed! Warnings found!</font><br/>"
			else file.puts "<font color='green'>Test passed. No warnings</font><br/>" end
		else
	
			file.puts "<h3>Testing for errors : " + errors + "</h3>"	
			errorarray = errors.split(/ /)
			
			
			
			0.upto(errorarray.length-1) do |error|
			
				if browser.text.include?("#{errorarray[error]}")
					file.puts "<font color='green'> #{errorarray[error]} DOES exist</font><br/>" 
				else
				    file.puts "<font color='red'>#{errorarray[error]} DOES NOT exist</font><br/>"
				end
			end 
			
					
		end
	end
end
	
main



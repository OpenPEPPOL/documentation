#!/bin/sh

#  CEN WS BII 2009
#
#  Validation artifact for the Invoice transaction in CEN BII 
#
#  Use ./validation_artifact.sh <xml instance> <xsd-schema> <CEN BII xslt>
# 
#  Defined by WG3. Editor Oriol Bausà

echo Validating Standard UBL Schema...
echo  w3cschema $2 $1
./w3cschema.sh $2 $1 2>&1 >output.txt
if [ $? -ne 0 ]; then 
	less output.txt
	exit 0
  fi
echo =====================================================================
echo           Standard UBL Schema validated without ERRORS
echo =====================================================================

#echo Validating CEN BII maximum data set...
#echo   w3cschema ../cenbii/restrictedxsdrt/maindoc/UBL-Restricted-Invoice-2.0.xsd invoice_instance.xml
#./w3cschema.sh ../cenbii/restrictedxsdrt/maindoc/UBL-Restricted-Invoice-2.0.xsd $1 2>&1 >output.txt
# if [ $? -ne 0 ]; then 
#	less output.txt
#	exit 0
#  fi
#echo =====================================================================
#echo           Restricted CEN BII dataset validated without ERRORS
#echo =====================================================================

echo
echo Validating CEN BII business rules and codes...
echo   xslt $1 $3 ../test-result/result${1:11}
./xslt.sh $1 $3 ../test-result/result${1:11}

./xslt.sh  ../test-result/result${1:11} ./svrl.xsl  ../test-result/result${1:11}.html
echo =====================================================================
echo           CEN BII business rules processes
echo		   Report on validation on result.html
echo =====================================================================

echo
echo Done.